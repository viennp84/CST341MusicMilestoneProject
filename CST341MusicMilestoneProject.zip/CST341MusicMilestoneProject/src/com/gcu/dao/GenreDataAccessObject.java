package com.gcu.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import com.gcu.model.Genre;

/*
 * Vien Nguyen
 * CST341
 * 10/24/2020
 * Genre Data Access Object
 * GenretDataAccessObject will implement findAll(), create(), update(), delete() methods
 */
@SuppressWarnings("unused")
public class GenreDataAccessObject {
	//Get the connection to database using Spring JDBC
	private DataSource dataSource;
	//Define a jdbcTemplateObject
	private JdbcTemplate jdbcTemplateObject;
	
    public void setDataSource(DataSource dataSource) 
    {
        this.dataSource = dataSource;
        this.jdbcTemplateObject = new JdbcTemplate(dataSource);
    }
   //The findAll method will get all Genre from the database, return a list of genre
	public List<Genre> findAll() {
		/*
		 * Search Genre on
		 * the Genre table
		 */
		List<Genre> list = new ArrayList<Genre>();
		String sql = "SELECT  genreId, name FROM  genre LIMIT 20 ";
		SqlRowSet rs = jdbcTemplateObject.queryForRowSet(sql);
		while(rs.next()) {
				list.add(new Genre(rs.getInt(1), rs.getString(2)));
		}
		return list;
	}

	/*
	 * Create method is overridden to create a new genre and save genre name to the
	 * database
	 */
	public boolean create(Genre genre) {

		boolean isCreated = false;
		/*
		 * Insert the genre name into 
		 * the genre table
		 */
		String sql = "INSERT INTO genre(name)"
				+ "values (?)";
		int rs = jdbcTemplateObject.update(sql, genre.getName());
		if(rs > 0) {
			isCreated = true;
		}
		return isCreated;
	}

	public boolean update(Genre genre) {
		boolean isUpdated = false;
		/*
		 * Update the genre name into 
		 * the genre table
		 */
		String sql = "UPDATE genre SET name = ?  WHERE genreId = ?";
		int rs = jdbcTemplateObject.update(sql, genre.getName(), genre.getGenreId());
		if(rs > 0){
			isUpdated = true;
		}
		return isUpdated;
	}

	public boolean delete(int id) {
		/*
		 * Delete the genre 
		 * from the genre table
		 */
		boolean isDeleted = false;
		String sql = "DELETE FROM genre  WHERE genreId = ?";
		int rs = jdbcTemplateObject.update(sql,id);
		if(rs > 0) {
			isDeleted = true;
		} 
		return isDeleted;
	}
}
