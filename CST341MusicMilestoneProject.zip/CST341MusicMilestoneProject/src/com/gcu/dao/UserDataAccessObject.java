package com.gcu.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.gcu.model.User;

/*
 * Vien Nguyen, Roland Steinebrunner
 * CST341
 * 10/03/2020
 * User Data Access Object
 * UserDataAccessObject will implement findAll(), create(), update(), delete() methods
 */
@SuppressWarnings("unused")
public class UserDataAccessObject {
	//Get the connection to database using Spring JDBC
	private DataSource dataSource;
	//Define a jdbcTemplateObject
	private JdbcTemplate jdbcTemplateObject;
	
    public void setDataSource(DataSource dataSource) 
    {
        this.dataSource = dataSource;
        this.jdbcTemplateObject = new JdbcTemplate(dataSource);
    }
    //The findAll method will get all User from the database, return a list of users
	public List<User> findAll() {
		/*
		 * Search user with the firstname, lastname, email, phone, username, password, gender into
		 * the table_user
		 */
		List<User> list = new ArrayList<User>();
		String sql = "SELECT  firstname, lastname, email, phone, username, gender FROM  table_user LIMIT 20 ";
		
		SqlRowSet rs = jdbcTemplateObject.queryForRowSet(sql);
		while(rs.next()) {
			list.add(new User(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),"", rs.getInt(6)));
		}
		return list;
	}

	/*
	 * Create method is overridden to create a new user save user information into
	 * database
	 */
	public boolean create(User user) {

		boolean isUserCreated = false;
		/*
		 * Insert the firstname, lastname, email, phone, username, password, gender into
		 * the table_user
		 */
		String sql = "INSERT INTO table_user(firstname, lastname, email, phone, username, password, gender)"
				+ "values (?, ?, ?, ?, ?, ?, ?)";

		int rs = jdbcTemplateObject.update(sql, user.getFirstName(), user.getLastName(),
				user.getEmail(), user.getPhone(), user.getUsername(), user.getPassword(), user.getGender());
		if(rs > 0) {
			isUserCreated = true;
		}
		return isUserCreated;
	}

	public boolean update(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean delete(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * login method is overridden to check the valid user in the database
	 */
	public boolean login(User user) {
		boolean isLoginValid = false;
		String sql = "SELECT * FROM table_user where username = ? and password = ?";
		
		SqlRowSet rs = jdbcTemplateObject.queryForRowSet(sql, user.getUsername(), user.getPassword());
		if (rs.next()) {
			isLoginValid = true;
		}
		return isLoginValid;
	}

}
