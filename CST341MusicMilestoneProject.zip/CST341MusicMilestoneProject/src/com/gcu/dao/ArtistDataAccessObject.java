package com.gcu.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.gcu.model.Artist;

/*
 * Vien Nguyen, Roland Steinebrunner
 * CST341
 * 10/24/2020
 * Artist Data Access Object
 * ArtistDataAccessObject will implement findAll(), create(), update(), delete() methods
 */
@SuppressWarnings("unused")
public class ArtistDataAccessObject {
	//Get the connection to database using Spring JDBC
	private DataSource dataSource;
	//Define a jdbcTemplateObject
	private JdbcTemplate jdbcTemplateObject;
	
    public void setDataSource(DataSource dataSource) 
    {
        this.dataSource = dataSource;
        this.jdbcTemplateObject = new JdbcTemplate(dataSource);
    }
    //The findAll method will get all Artist from the database, return a list of artists
	public List<Artist> findAll() {
		/*
		 * Search Artist with the artist name
		 * the Artist table
		 */
		List<Artist> list = new ArrayList<Artist>();
		String sql = "SELECT artistId, name FROM artist LIMIT 20 ";
		SqlRowSet rs = jdbcTemplateObject.queryForRowSet(sql);
		while(rs.next()) {
			list.add(new Artist(rs.getInt(1), rs.getString(2)));
		}
		return list;
	}
	public Artist findById(int id) {
		/*
		 * Search Artist with the artist name
		 * the Artist table
		 */
		Artist result = null;
		String sql = "SELECT * FROM artist WHERE artistId = ? ";
		SqlRowSet rs = jdbcTemplateObject.queryForRowSet(sql, id);
		if (rs.next()) {
			result = new Artist(rs.getInt(1), rs.getString(2));
		}
		return result;
	}

	/*
	 * Create method is overridden to create a new artist and save artist name to the
	 * database
	 */
	public boolean create(Artist artist) {

		boolean isCreated = false;
		/*
		 * Insert the artist name into 
		 * the artist
		 */
		String sql = "INSERT INTO artist(name)"
				+ "values (?)";
		int rs = jdbcTemplateObject.update(sql,artist.getArtistName());
		if(rs > 0) {
			isCreated = true;
		}
		return isCreated;
	}

	public boolean update(Artist artist) {
		boolean isUpdated = false;
		/*
		 * Update the artist name into 
		 * the artist table
		 */
		String sql = "UPDATE artist SET name = ?  WHERE artistId = ?";
		int rs = jdbcTemplateObject.update(sql,artist.getArtistName(), artist.getArtistId());
		if(rs > 0)
			isUpdated = true;
		return isUpdated;
	}

	public boolean delete(int id){
		/*
		 * Delete the artist 
		 * from the artist table
		 */
		boolean isDeleted = false;
		String sql = "DELETE FROM artist WHERE artistId = ?";
		int rs = jdbcTemplateObject.update(sql, id);
		if(rs > 0)
			isDeleted = true;
		return isDeleted;
	}

}
