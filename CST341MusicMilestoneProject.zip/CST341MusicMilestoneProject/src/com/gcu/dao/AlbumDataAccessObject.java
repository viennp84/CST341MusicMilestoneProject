package com.gcu.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.gcu.model.Album;

/*
 * Vien Nguyen
 * CST341
 * 10/24/2020
 * Album Data Access Object
 * AlbumDataAccessObject will implement findAll(), create(), update(), delete() methods
 */
@SuppressWarnings("unused")
public class AlbumDataAccessObject {
	
	//Get the connection to database using Spring JDBC
	private DataSource dataSource;
	//Define a jdbcTemplateObject
	private JdbcTemplate jdbcTemplateObject;
	
    public void setDataSource(DataSource dataSource) 
    {
        this.dataSource = dataSource;
        this.jdbcTemplateObject = new JdbcTemplate(dataSource);
    }
    //The findAll method will get all Album from the database, return a list of Albums
	public List<Album> findAll() {
		/*
		 * Search Album on
		 * the album table
		 */
		List<Album> list = new ArrayList<Album>();
		String sql = "SELECT albumId, title, artistId FROM  album LIMIT 20 ";
		SqlRowSet rs = jdbcTemplateObject.queryForRowSet(sql);
		while(rs.next()) {
			list.add(new Album(rs.getInt(1), rs.getString(2), rs.getInt(3)));
		}
		return list;
	}

	/*
	 * Create method is overridden to create a new album and save album name to the
	 * database
	 */
	public boolean create(Album album) {

		boolean isCreated = false;
		/*
		 * Insert the album name into 
		 * the album table
		 */
		String sql = "INSERT INTO album(title, artistId)"
				+ "values (?,?)";
		int rs = jdbcTemplateObject.update(sql, album.getTitle(), album.getArtistId());
		if(rs > 0)
			isCreated = true;
		return isCreated;
	}

	public boolean update(Album album) {
		boolean isUpdated = false;
		/*
		 * Update the album into 
		 * the album table
		 */
		String sql = "UPDATE album SET title = ?, artistId = ?  WHERE albumId = ?";
		int rs = jdbcTemplateObject.update(sql, album.getTitle(), album.getArtistId(), album.getAlbumId());
		if(rs > 0)
			isUpdated = true;
		return isUpdated;
	}

	public boolean delete(int id) {
		/*
		 * Delete the album 
		 * from the album table
		 */
		boolean isDeleted = false;
		String sql = "DELETE FROM album WHERE albumId = ?";
		int rs = jdbcTemplateObject.update(sql, id);
		if(rs > 0)
			isDeleted = true;
		return isDeleted;
	}
}
